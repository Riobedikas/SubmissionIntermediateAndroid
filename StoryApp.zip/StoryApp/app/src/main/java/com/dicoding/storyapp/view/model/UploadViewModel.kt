package com.dicoding.storyapp.view.model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.dicoding.storyapp.repository.UserRepository
import java.io.File

class UploadViewModel(private val repository: UserRepository) : ViewModel() {
    fun getSession() = repository.getSession().asLiveData()
    fun uploadImage(token: String, file: File, description: String) = repository.getUpload(token, file, description)
}