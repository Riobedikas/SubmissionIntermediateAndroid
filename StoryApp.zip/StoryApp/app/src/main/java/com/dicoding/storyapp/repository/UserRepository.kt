package com.dicoding.storyapp.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.storyapp.data.StoryPagingSource
import com.dicoding.storyapp.preference.UserPreference
import com.dicoding.storyapp.response.ListStoryItem
import com.dicoding.storyapp.retrofit.ApiService
import kotlinx.coroutines.Dispatchers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class UserRepository private constructor(
    private val apiService: ApiService, private val userPreference: UserPreference
) {

    fun getSession() = userPreference.getSession()

    suspend fun logout() = userPreference.logout()


    fun getStory(token: String): LiveData<PagingData<ListStoryItem>> {
        return Pager(config = PagingConfig(pageSize = 5),
            pagingSourceFactory = { StoryPagingSource( apiService,"Bearer $token") }).liveData

    }

    fun getUpload(token: String, imageFile: File, description: String) = liveData {
        emit(Result.Loading)
        val requestBody = description.toRequestBody("text/plain".toMediaType())
        val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData(
            "photo", imageFile.name, requestImageFile
        )
        try {
            val successResponse =
                apiService.getUpload("Bearer $token", multipartBody, requestBody)
            emit(Result.Success(successResponse))
        } catch (e: Exception) {
            emit(Result.Error("${e.message}"))
        }
    }

    fun getStoriesWithLocation(token: String): LiveData<Result<List<ListStoryItem>>> =
        liveData(Dispatchers.IO) {
            emit(Result.Loading)
            try {
                val response = apiService.getStoriesWithLocation("Bearer $token")
                val data = response.listStory
                emit(Result.Success(data))
            } catch (e: Exception) {
                emit(Result.Error("${e.message}"))
            }
        }


    companion object {
        @Volatile
        private var instance: UserRepository? = null
        fun getInstance(
            apiService: ApiService, userPreference: UserPreference
        ): UserRepository = instance ?: synchronized(this) {
            instance ?: UserRepository(apiService, userPreference)
        }.also { instance = it }
    }

}
