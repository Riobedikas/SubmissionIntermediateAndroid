package com.dicoding.storyapp.di

import android.content.Context
import com.dicoding.storyapp.preference.UserPreference
import com.dicoding.storyapp.preference.dataStore
import com.dicoding.storyapp.repository.AuthRepository
import com.dicoding.storyapp.repository.UserRepository
import com.dicoding.storyapp.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val apiService = ApiConfig.getApiService()
        val pref = UserPreference.getInstance(context.dataStore)
        return UserRepository.getInstance(apiService, pref)
    }

    fun provideAuthRepository(context: Context): AuthRepository {
        val apiService = ApiConfig.getApiService()
        val pref = UserPreference.getInstance(context.dataStore)
        return AuthRepository.getInstance(apiService, pref)
    }
}
