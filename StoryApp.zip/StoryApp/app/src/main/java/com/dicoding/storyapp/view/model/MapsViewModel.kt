package com.dicoding.storyapp.view.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.dicoding.storyapp.preference.UserModel
import com.dicoding.storyapp.repository.Result
import com.dicoding.storyapp.repository.UserRepository
import com.dicoding.storyapp.response.ListStoryItem

class MapsViewModel(private val repository: UserRepository): ViewModel() {
    private val _liveData = MediatorLiveData<Result<List<ListStoryItem>>>()
    val locationLiveData : LiveData<Result<List<ListStoryItem>>> = _liveData

    fun getStoriesWithLocation(token:String){
        val response = repository.getStoriesWithLocation(token)
        _liveData.addSource(response){
            result  ->
            _liveData.value=result
        }
    }

    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }
}

