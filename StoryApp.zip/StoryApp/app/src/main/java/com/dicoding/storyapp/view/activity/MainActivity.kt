package com.dicoding.storyapp.view.activity

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.storyapp.R
import com.dicoding.storyapp.databinding.ActivityMainBinding
import com.dicoding.storyapp.view.adapter.LoadingStateAdapter
import com.dicoding.storyapp.view.adapter.StoryAdapter
import com.dicoding.storyapp.view.model.MainViewModel
import com.dicoding.storyapp.view.model.ViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupView()
        getData()
        showLoading(true)

        val layoutManager = LinearLayoutManager(this)
        binding.rvHome.layoutManager = layoutManager

        val newStory = findViewById<FloatingActionButton>(R.id.button_add)
        newStory.setOnClickListener {
            val intent = Intent(this, AddStoryActivity::class.java)
            startActivity(intent)
        }

        binding.topAppBar.setOnMenuItemClickListener { menuItem ->
            when (
                menuItem.itemId
            ) {
                R.id.btnLogout -> {
                    viewModel.logout()
                    val intent = Intent(this, WelcomeActivity::class.java)
                    startActivity(intent)
                    true
                }

                R.id.btnMap -> {
                    val intent = Intent(this, MapsActivity::class.java)
                    startActivity(intent)
                    true
                }

                else -> false
            }
        }

        viewModel.getSession().observe(this) { user ->
            if (user.isLogin && user != null) {
                viewModel.getList
                Toast.makeText(this, "Sukses Menampilkan Data", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun getData() {
        val adapter = StoryAdapter()
        binding.rvHome.adapter= adapter.withLoadStateFooter(footer = LoadingStateAdapter {
            adapter.retry()
        })
        viewModel.getList.observe(this) { paging ->
            if (paging != null) {
                adapter.submitData(lifecycle, paging)
                showLoading(false)
                hideInfoMessage()
            } else {
                showLoading(true)
                showInfoMessage("List Story Tidak Tersedia")
            }
        }
    }

    private fun showInfoMessage(message: String) {
        binding.infoMessage.text = message
        binding.infoMessage.visibility = View.VISIBLE
    }

    private fun hideInfoMessage() {
        binding.infoMessage.visibility = View.GONE
    }

    private fun showLoading(isLoading: Boolean) {
        binding.pbHome.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

}