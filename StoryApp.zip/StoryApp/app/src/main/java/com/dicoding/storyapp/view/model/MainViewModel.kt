package com.dicoding.storyapp.view.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.storyapp.preference.UserModel
import com.dicoding.storyapp.repository.UserRepository
import com.dicoding.storyapp.response.ListStoryItem
import kotlinx.coroutines.launch

class MainViewModel(private val repository: UserRepository) : ViewModel() {
    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()

    }

    private fun getToken(): String {
        var tokenUser = ""
        viewModelScope.launch {
            repository.getSession().collect { token ->
                tokenUser = token.token
            }
        }
        return tokenUser
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    val getList: LiveData<PagingData<ListStoryItem>> =
        repository.getStory(getToken()).cachedIn(viewModelScope)
}