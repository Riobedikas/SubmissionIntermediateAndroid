package com.dicoding.storyapp.view.model

import androidx.lifecycle.ViewModel
import com.dicoding.storyapp.preference.UserModel
import com.dicoding.storyapp.repository.AuthRepository
import com.dicoding.storyapp.repository.Result

class LoginViewModel (private val repository: AuthRepository) : ViewModel() {
    suspend fun saveSession(user: UserModel) {
        repository.saveSession(user)
    }
    suspend fun login(email: String, password: String): Result<UserModel>{
        return repository.getLogin(email, password)
    }
}