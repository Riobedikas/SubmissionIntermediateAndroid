package com.dicoding.storyapp.repository

import com.dicoding.storyapp.preference.UserModel
import com.dicoding.storyapp.preference.UserPreference
import com.dicoding.storyapp.retrofit.ApiService

class AuthRepository private constructor(
    private val apiService: ApiService, private val userPreference: UserPreference
) {
    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    suspend fun getSignUp(name: String, email: String, password: String): Result<Boolean> {
        return try {
            apiService.register(name, email, password).message
            Result.Success(true)
        } catch (e: Exception) {
            Result.Error(e.message ?: "Terjadi Kesalahan!")
        }
    }

    suspend fun getLogin(email: String, password: String): Result<UserModel> {
        return try {
            val loginResponse = apiService.login(email, password)
            run {
                val userModel = UserModel(
                    email = loginResponse.loginResult.name ?: "",
                    token = loginResponse.loginResult.token ?: "",
                    isLogin = true
                )
                userPreference.saveSession(userModel)
                Result.Success(userModel)
            }
        } catch (e: Exception) {
            Result.Error(e.message ?: "Terjadi Kesalahan!")
        }
    }

    companion object {
        @Volatile
        private var instance: AuthRepository? = null
        fun getInstance(
            apiService: ApiService, userPreference: UserPreference
        ): AuthRepository = instance ?: synchronized(this) {
            instance ?: AuthRepository(apiService, userPreference)
        }.also { instance = it }
    }
}