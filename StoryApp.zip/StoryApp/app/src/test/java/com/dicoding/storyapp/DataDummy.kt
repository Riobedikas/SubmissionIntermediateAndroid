package com.dicoding.storyapp

import com.dicoding.storyapp.response.ListStoryItem

object DataDummy {
    fun generateDummyStoryResponse(): List<ListStoryItem> {
        val item: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..100) {
            val storyItem = ListStoryItem(
                id = "story-PbpGJButYxV9bep1",
                photoUrl = "https://story-api.dicoding.dev/images/stories/photos-1700327517134_PQ1CKCRR.jpg",
                name = "permisi",
                lat = -6.895136202604699,
                lon = 107.63401117175817,
                description = "tetteww${ i + 1}",
                createdAt = "2023-11-18T17:11:57.140Z"


            )
            item.add(storyItem)
        }
        return item
    }
}